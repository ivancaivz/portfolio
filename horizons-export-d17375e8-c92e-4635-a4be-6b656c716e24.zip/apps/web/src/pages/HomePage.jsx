
import React from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { 
  ArrowRight, 
  Instagram, 
  Linkedin, 
  Facebook,
  Star,
  Smartphone,
  User,
  Youtube,
  Camera,
  Megaphone,
  Sparkles,
  Music,
  Building,
  ShoppingCart,
  Film,
  Mic
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const TikTokIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 15.68a6.34 6.34 0 006.35 6.32 6.32 6.32 0 006.31-6.24v-6.9a8.09 8.09 0 005 1.76v-3.4a4.67 4.67 0 01-3.07-.53z" />
  </svg>
);

const StarRating = ({ rating }) => {
  return (
    <div className="flex gap-1 mt-2">
      {[1, 2, 3, 4, 5].map((star) => (
        <Star
          key={star}
          className={`h-5 w-5 ${
            star <= rating
              ? 'fill-primary text-primary'
              : 'fill-muted text-muted'
          }`}
        />
      ))}
    </div>
  );
};

const HomePage = () => {
  const socialLinks = [
    {
      icon: Instagram,
      href: 'https://www.instagram.com/johnnyparagoso/',
      label: 'Instagram',
    },
    {
      icon: Linkedin,
      href: 'https://www.linkedin.com/in/johnny-paragoso-9b5a161b',
      label: 'LinkedIn',
    },
    {
      icon: Facebook,
      href: 'https://facebook.com/johny.paragoso',
      label: 'Facebook',
    },
    {
      icon: TikTokIcon,
      href: 'https://www.tiktok.com/@john_aiexperts',
      label: 'TikTok',
    },
  ];

  const skills = [
    { name: 'AI Video Editor', rating: 5 },
    { name: 'Graphic Design', rating: 4 },
    { name: 'SMM', rating: 4 },
    { name: 'AI Experts', rating: 4 },
    { name: 'Adobe Premiere', rating: 4 },
    { name: 'CapCut', rating: 5 },
  ];

  const services = [
    { name: 'Reels', icon: Smartphone },
    { name: 'Talking Head', icon: User },
    { name: 'YouTube Video', icon: Youtube },
    { name: 'UGC Video', icon: Camera },
    { name: 'Advertisement', icon: Megaphone },
    { name: 'AI Content Creation', icon: Sparkles },
    { name: 'Music Video', icon: Music },
    { name: 'Real Estate', icon: Building },
    { name: 'Ecommerce', icon: ShoppingCart },
    { name: 'Long Form', icon: Film },
    { name: 'Podcast', icon: Mic },
  ];

  const containerVariants = {
    hidden: { opacity: 0 },
    show: {
      opacity: 1,
      transition: { staggerChildren: 0.1 }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    show: { opacity: 1, y: 0, transition: { duration: 0.5 } }
  };

  return (
    <>
      <Helmet>
        <title>Johnny Paragoso - AI Video Editor & Graphic Designer</title>
        <meta
          name="description"
          content="AI Video Editor and Graphic Designer specializing in short-form content, YouTube editing, ads, and AI-driven content creation."
        />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1">
          {/* Hero Section */}
          <section className="relative min-h-[100dvh] flex items-center justify-center overflow-hidden pt-16">
            <div
              className="absolute inset-0 z-0"
              style={{
                backgroundImage:
                  'url(https://images.unsplash.com/photo-1604871670116-4b3e1064f77e)',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                backgroundRepeat: 'no-repeat',
              }}
            >
              <div className="absolute inset-0 bg-gradient-to-b from-background/95 via-background/90 to-background" />
            </div>

            <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center py-20">
              <motion.div
                initial={{ opacity: 0, y: 30 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.8 }}
              >
                <div className="mb-6 inline-flex items-center rounded-full border border-primary/30 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                  AI Video Editor, Graphic Designer, SMM
                </div>
                <h1
                  className="font-display text-4xl md:text-5xl lg:text-7xl font-bold text-foreground mb-6 leading-tight text-balance mx-auto max-w-5xl"
                  style={{ letterSpacing: '-0.02em' }}
                >
                  AI Video Editor | Content That Captures Attention and Converts
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground mb-10 max-w-3xl mx-auto leading-relaxed text-balance">
                  I help brands, creators, and businesses turn ideas into
                  high-impact video content that drives engagement and results.
                </p>

                <div className="flex flex-col sm:flex-row gap-4 justify-center mb-16">
                  <Button
                    asChild
                    size="lg"
                    className="bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] transition-all duration-200 text-base h-12 px-8"
                  >
                    <Link to="/contact">Ready to level up your content?</Link>
                  </Button>
                  <Button
                    asChild
                    size="lg"
                    variant="outline"
                    className="hover:bg-muted active:scale-[0.98] transition-all duration-200 text-base h-12 px-8"
                  >
                    <Link to="/portfolio">
                      View My Portfolio
                      <ArrowRight className="ml-2 h-5 w-5" />
                    </Link>
                  </Button>
                </div>

                <div className="flex flex-col items-center justify-center gap-4 pt-8 border-t border-border/50 max-w-lg mx-auto">
                  <p className="text-sm font-medium text-muted-foreground uppercase tracking-wider">
                    Connect with me
                  </p>
                  <div className="flex gap-4 sm:gap-6">
                    {socialLinks.map((social) => {
                      const Icon = social.icon;
                      return (
                        <a
                          key={social.label}
                          href={social.href}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="w-12 h-12 rounded-full bg-card/50 border border-border flex items-center justify-center text-muted-foreground hover:text-primary hover:border-primary hover:bg-primary/10 transition-all duration-300"
                          aria-label={social.label}
                        >
                          <Icon className="h-5 w-5" />
                        </a>
                      );
                    })}
                  </div>
                </div>
              </motion.div>
            </div>
          </section>

          {/* Skills Section */}
          <section className="py-24 bg-muted/30 border-y border-border/50">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-center mb-16"
              >
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Professional Skills
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
                  A comprehensive toolkit of creative and technical capabilities tailored for modern content creation.
                </p>
              </motion.div>

              <motion.div 
                variants={containerVariants}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-100px" }}
                className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-5xl mx-auto"
              >
                {skills.map((skill) => (
                  <motion.div
                    key={skill.name}
                    variants={itemVariants}
                    className="group flex flex-col items-center justify-center p-8 rounded-2xl bg-card border border-border hover:border-primary/50 hover:shadow-lg transition-all duration-300 hover:-translate-y-1"
                  >
                    <h3 className="text-xl font-bold text-foreground mb-3">{skill.name}</h3>
                    <div className="bg-muted/50 px-4 py-2 rounded-full group-hover:bg-primary/5 transition-colors duration-300">
                      <StarRating rating={skill.rating} />
                    </div>
                  </motion.div>
                ))}
              </motion.div>
            </div>
          </section>

          {/* Services Section */}
          <section className="py-24 bg-background">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="text-center mb-16"
              >
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-4">
                  Services Offered
                </h2>
                <p className="text-lg text-muted-foreground max-w-2xl mx-auto text-balance">
                  From short-form attention grabbers to long-form storytelling, I provide versatile editing services for all platforms.
                </p>
              </motion.div>

              <motion.div 
                variants={containerVariants}
                initial="hidden"
                whileInView="show"
                viewport={{ once: true, margin: "-100px" }}
                className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4 md:gap-6"
              >
                {services.map((service) => {
                  const Icon = service.icon;
                  return (
                    <motion.div
                      key={service.name}
                      variants={itemVariants}
                      className="group flex flex-col items-center text-center p-6 rounded-2xl bg-muted/40 border border-transparent hover:bg-card hover:border-border hover:shadow-md transition-all duration-300"
                    >
                      <div className="w-14 h-14 rounded-xl bg-background border border-border/50 flex items-center justify-center mb-4 group-hover:scale-110 group-hover:border-primary/50 group-hover:text-primary transition-all duration-300 text-muted-foreground shadow-sm">
                        <Icon className="h-6 w-6" />
                      </div>
                      <h3 className="font-medium text-foreground text-sm md:text-base leading-tight">
                        {service.name}
                      </h3>
                    </motion.div>
                  );
                })}
              </motion.div>
            </div>
          </section>

          {/* CTA Section */}
          <section className="py-24 bg-primary/5 border-t border-border/50">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="font-display text-3xl md:text-4xl font-bold text-foreground mb-6">
                  Ready to level up your content?
                </h2>
                <p className="text-lg text-muted-foreground mb-8 max-w-2xl mx-auto text-balance">
                  Let's create videos that stand out and perform. From concept to final
                  cut, I'll help you tell your story with impact.
                </p>
                <Button
                  asChild
                  size="lg"
                  className="bg-primary text-primary-foreground hover:bg-primary/90 active:scale-[0.98] transition-all duration-200 h-12 px-8"
                >
                  <Link to="/contact">
                    Start a Project
                    <ArrowRight className="ml-2 h-5 w-5" />
                  </Link>
                </Button>
              </motion.div>
            </div>
          </section>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default HomePage;
