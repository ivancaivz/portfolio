
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Briefcase, GraduationCap, Calendar, MapPin, PlayCircle } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';

const AboutPage = () => {
  const experiences = [
    {
      role: 'Senior Video Editor',
      company: 'NBK Brain Jolt',
      period: '2025 - 2026',
      description: 'Collaborated with clients and creative strategies to produce high-impact social media videos and engaging digital content.'
    },
    {
      role: 'Senior Video Editor',
      company: 'Jolt US Agency',
      period: '2024 - 2025',
      description: 'Provided professional video editing services focused on modern content performance and audience retention, specializing in:',
      specialties: [
        'Podcast Editing',
        'Long-Form Video Content',
        'Real Estate Videos',
        'Reels & Talking Head Content'
      ]
    },
    {
      role: 'Freelance Video Editor',
      company: 'Self-Employed',
      period: '2019 - 2024',
      type: 'Full-Time / Part-Time',
      description: 'Collaborated directly with clients for bulk video production, functioning as a senior video editor for diverse projects.'
    }
  ];

  const education = [
    {
      degree: 'Adobe Master Class',
      institution: 'Graphics Media Philippines',
      date: 'August 2022'
    },
    {
      degree: 'Information Communication Technology',
      institution: 'Technical Vocational Course',
      date: 'Graduated June 2016'
    }
  ];

  return (
    <>
      <Helmet>
        <title>About - Johnny Paragoso</title>
        <meta name="description" content="Learn about Johnny Paragoso's professional journey, work experience at NBK Brain Jolt and Jolt US Agency, and comprehensive background in video editing and graphic design." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 pt-24 pb-20">
          <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Header / Intro */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-20 border-b border-border pb-16"
            >
              <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-6">
                Professional Journey
              </h1>
              <div className="text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed text-left sm:text-center space-y-4">
                <p>
                  I'm Johnny Paragoso Jr., a video editor with 6+ years of experience specializing in AI-powered editing and social media content.
                </p>
                <p>
                  From raw footage to polished final cuts, I create videos designed to:
                </p>
                <ul className="flex flex-col items-center sm:items-start sm:inline-block gap-2 text-left mt-4 mx-auto max-w-sm">
                  <li className="flex items-center gap-3">
                    <PlayCircle className="w-5 h-5 text-primary shrink-0" />
                    <span className="text-foreground">Capture attention instantly</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <PlayCircle className="w-5 h-5 text-primary shrink-0" />
                    <span className="text-foreground">Keep viewers engaged</span>
                  </li>
                  <li className="flex items-center gap-3">
                    <PlayCircle className="w-5 h-5 text-primary shrink-0" />
                    <span className="text-foreground">Communicate your message clearly</span>
                  </li>
                </ul>
              </div>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-12 gap-12">
              
              {/* Work Experience Section */}
              <motion.div 
                initial={{ opacity: 0, x: -20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
                className="lg:col-span-7 space-y-8"
              >
                <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Briefcase className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-foreground">
                    Work Experience
                  </h2>
                </div>

                <div className="space-y-8">
                  {experiences.map((exp, index) => (
                    <div key={index} className="relative pl-8 before:absolute before:inset-y-0 before:left-[11px] before:w-px before:bg-border last:before:hidden">
                      <div className="absolute left-0 top-1.5 w-[23px] h-[23px] rounded-full bg-background border-4 border-primary/20 flex items-center justify-center">
                        <div className="w-2.5 h-2.5 rounded-full bg-primary" />
                      </div>
                      
                      <div className="bg-card border border-border rounded-xl p-6 shadow-sm hover:shadow-md transition-shadow">
                        <h3 className="text-xl font-semibold text-foreground mb-1">{exp.role}</h3>
                        <div className="flex flex-wrap items-center gap-3 text-sm text-muted-foreground mb-4">
                          <span className="font-medium text-primary">{exp.company}</span>
                          <span className="flex items-center gap-1">
                            <Calendar className="h-3.5 w-3.5" />
                            {exp.period}
                          </span>
                          {exp.type && (
                            <span className="px-2 py-0.5 rounded-full bg-muted text-xs font-medium">
                              {exp.type}
                            </span>
                          )}
                        </div>
                        <p className="text-muted-foreground leading-relaxed mb-4">
                          {exp.description}
                        </p>
                        {exp.specialties && (
                          <ul className="space-y-2 mt-4 pt-4 border-t border-border/50">
                            {exp.specialties.map((specialty, idx) => (
                              <li key={idx} className="flex items-center gap-2 text-sm text-muted-foreground">
                                <span className="w-1.5 h-1.5 rounded-full bg-primary/60" />
                                {specialty}
                              </li>
                            ))}
                          </ul>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>

              {/* Education Section */}
              <motion.div 
                initial={{ opacity: 0, x: 20 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="lg:col-span-5 space-y-8"
              >
                <div className="flex items-center gap-3 mb-8 pb-4 border-b border-border">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <GraduationCap className="h-6 w-6 text-primary" />
                  </div>
                  <h2 className="font-display text-2xl font-bold text-foreground">
                    Education
                  </h2>
                </div>

                <div className="space-y-6">
                  {education.map((edu, index) => (
                    <div key={index} className="bg-muted/40 rounded-xl p-6 border border-border/50">
                      <h3 className="text-lg font-semibold text-foreground mb-2">
                        {edu.degree}
                      </h3>
                      <div className="space-y-2 text-sm text-muted-foreground">
                        <p className="flex items-center gap-2">
                          <MapPin className="h-4 w-4 text-primary/70" />
                          {edu.institution}
                        </p>
                        <p className="flex items-center gap-2">
                          <Calendar className="h-4 w-4 text-primary/70" />
                          {edu.date}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>

                <div className="mt-12 bg-card border border-border rounded-2xl p-8 text-center">
                  <h3 className="font-display text-xl font-bold text-card-foreground mb-4 text-balance">
                    Ready to level up your content?
                  </h3>
                  <p className="text-muted-foreground mb-6 text-sm leading-relaxed text-balance">
                    Let's create videos that stand out and perform.
                  </p>
                  <a href="/contact" className="inline-flex items-center justify-center px-6 py-3 rounded-lg bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors">
                    Get in Touch
                  </a>
                </div>
              </motion.div>

            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default AboutPage;
