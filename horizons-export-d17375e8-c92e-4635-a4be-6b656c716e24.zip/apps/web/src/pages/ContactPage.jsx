
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import ContactForm from '@/components/ContactForm.jsx';

const ContactPage = () => {
  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'paragosojohnny@gmail.com',
      href: 'mailto:paragosojohnny@gmail.com'
    },
    {
      icon: Phone,
      label: 'Phone',
      value: '+63 936 6674 832',
      href: 'tel:+639366674832'
    },
    {
      icon: MapPin,
      label: 'Location',
      value: 'Valencia City, Bukidnon, Philippines',
      href: null
    }
  ];

  return (
    <>
      <Helmet>
        <title>Contact - Johnny Paragoso</title>
        <meta name="description" content="Get in touch with Johnny Paragoso for video editing and graphic design projects. Based in Valencia City, Bukidnon, Philippines." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 pt-24 pb-20">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="text-center mb-16"
            >
              <h1 className="font-display text-4xl md:text-5xl font-bold text-foreground mb-4">
                Let's Work Together
              </h1>
              <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
                Have a project in mind? I'd love to hear about it. Fill out the form below and I'll get back to you within 24 hours.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
              {/* Contact Form */}
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.2 }}
                className="bg-card rounded-2xl p-8 shadow-lg border border-border"
              >
                <h2 className="text-2xl font-semibold text-card-foreground mb-6">
                  Send a Message
                </h2>
                <ContactForm />
              </motion.div>

              {/* Contact Information */}
              <motion.div
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.6, delay: 0.4 }}
                className="space-y-8"
              >
                <div>
                  <h2 className="text-2xl font-semibold text-foreground mb-6">
                    Contact Information
                  </h2>
                  <div className="space-y-4">
                    {contactInfo.map((info, index) => {
                      const Icon = info.icon;
                      const content = (
                        <div className="flex items-start gap-4 p-5 rounded-xl bg-muted/50 border border-border/50 hover:bg-muted transition-colors duration-200">
                          <div className="flex-shrink-0 w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
                            <Icon className="h-6 w-6 text-primary" />
                          </div>
                          <div className="flex flex-col justify-center min-h-[48px]">
                            <p className="text-sm font-medium text-muted-foreground mb-0.5">
                              {info.label}
                            </p>
                            <p className="text-base font-medium text-foreground">
                              {info.value}
                            </p>
                          </div>
                        </div>
                      );

                      return info.href ? (
                        <a key={index} href={info.href} className="block">
                          {content}
                        </a>
                      ) : (
                        <div key={index}>
                          {content}
                        </div>
                      );
                    })}
                  </div>
                </div>

                <div className="bg-card border border-border rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-card-foreground mb-4">
                    What to Expect
                  </h3>
                  <ul className="space-y-4 text-muted-foreground">
                    <li className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-medium mt-0.5">
                        1
                      </span>
                      <span>Creating high-impact videos that capture attention, build engagement, and deliver results.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-medium mt-0.5">
                        2
                      </span>
                      <span>Transforming raw footage into cinematic content designed to grow brands and creators.</span>
                    </li>
                    <li className="flex items-start gap-3">
                      <span className="flex-shrink-0 w-6 h-6 rounded-full bg-primary/10 flex items-center justify-center text-primary text-sm font-medium mt-0.5">
                        3
                      </span>
                      <span>Professional video editing focused on storytelling, audience retention, and modern content performance.</span>
                    </li>
                  </ul>
                </div>

                <div className="bg-muted/50 border border-border/50 rounded-2xl p-8">
                  <h3 className="text-xl font-semibold text-foreground mb-4">
                    Availability
                  </h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">
                    Currently available for freelance and remote projects with flexible hours, fast turnaround times, and open for long-term collaborations.
                  </p>
                  <div className="flex items-center gap-3">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                    </span>
                    <span className="text-sm font-medium text-foreground">
                      Available for new projects
                    </span>
                  </div>
                </div>
              </motion.div>
            </div>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default ContactPage;
