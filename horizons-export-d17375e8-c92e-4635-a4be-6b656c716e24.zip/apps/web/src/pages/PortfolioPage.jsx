
import React, { useState } from 'react';
import { Helmet } from 'react-helmet';
import { motion, AnimatePresence } from 'framer-motion';
import { Film } from 'lucide-react';
import Header from '@/components/Header.jsx';
import Footer from '@/components/Footer.jsx';
import VideoCard from '@/components/VideoCard.jsx';
import ProjectFilter from '@/components/ProjectFilter.jsx';

const PortfolioPage = () => {
  const categories = [
    'All', 
    'AI Videos', 
    'UGC Videos', 
    'Short Form', 
    'Real Estate', 
    'Long Form', 
    'Graphics', 
    'Self Introduction'
  ];
  const [activeCategory, setActiveCategory] = useState('All');

  // Helper object to store raw URLs organized by category
  const rawLinks = {
    'AI Videos': [
      'https://drive.google.com/file/d/10MhLVigpGbWS9nItrCqbcBTLsfzNI3GL/view?usp=sharing',
      'https://drive.google.com/file/d/1AGGyKKHiD5fwlsXYCj9S9jpm_ObgqZkH/view?usp=sharing',
      'https://drive.google.com/file/d/1BaSwu5fl4YWu9Rv5F3iff8kuVrRiO9sV/view?usp=sharing',
      'https://drive.google.com/file/d/1MT8PrCDHH7dH_NxlKp5SQAfoZOtZs050/view?usp=sharing',
      'https://drive.google.com/file/d/1XKuBnsBb7e6nj_RvPO7RJx6h4uYWmVrA/view?usp=sharing',
      'https://drive.google.com/file/d/1ZXPu1XFASV2kao6AcLk_nFiWQPRq5xe4/view?usp=sharing',
      'https://drive.google.com/file/d/1kWs2LXeUSWlHhiWrRlqntyyxt1i27LBn/view?usp=sharing',
      'https://drive.google.com/file/d/1lQMUTe9I0IxaFms3FXjjD8dLfgDTMUSF/view?usp=sharing'
    ],
    'UGC Videos': [
      'https://drive.google.com/file/d/1458Wy-_PpNkohVLw9BmD3wduhzinQWQt/view?usp=sharing',
      'https://drive.google.com/file/d/1dAEDAmv3bzGMGQdU5FPfVuQFq1qFrW6R/view?usp=sharing',
      'https://drive.google.com/file/d/1ksS3tbw3IKllR4nTtoJ18nv-mOy8lBut/view?usp=sharing',
      'https://drive.google.com/file/d/1xiKZsg3fhHfRRiqXLfUmVy_EO9H4xAYx/view?usp=sharing',
      'https://drive.google.com/file/d/1yRskyU3WyzIdaITu-YMNXWvARNDWSlq2/view?usp=sharing'
    ],
    'Short Form': [
      'https://drive.google.com/file/d/12B497qXGe-ERhtIiGeywfFqrHG1mvAn9/view?usp=sharing',
      'https://drive.google.com/file/d/13nHMOBHqWy3sKdr_CQ4L49FKURjiSF5e/view?usp=sharing',
      'https://drive.google.com/file/d/14XywQYUI3vE24YHib0DNi-wQWfCe0RtC/view?usp=sharing',
      'https://drive.google.com/file/d/17urza7uXKtEYYd3gNHA-pZ6RakU8Vgg2/view?usp=sharing',
      'https://drive.google.com/file/d/1AORB1pE-cLvaXCq7PHwW-dkNW2ud6z2B/view?usp=sharing',
      'https://drive.google.com/file/d/1C5svvjrTah0uqLRZ5film2k9A8Mt__J3/view?usp=sharing',
      'https://drive.google.com/file/d/1CIcyvHWD-oxFEADX79I-UScSL5kSEnma/view?usp=sharing',
      'https://drive.google.com/file/d/1EJaFmQWiAk6T68JgQvfKfTQw7H4Oh36X/view?usp=sharing',
      'https://drive.google.com/file/d/1IzmBHvad2DscHJl3XYjKIxfT4A8v8H-9/view?usp=sharing',
      'https://drive.google.com/file/d/1JD0sgjpZ4pp-ymzlJKxY3iaewFQytvci/view?usp=sharing',
      'https://drive.google.com/file/d/1LU_C5f0R15bYQZ1pvdAl3zUZpBcevlou/view?usp=sharing',
      'https://drive.google.com/file/d/1M2c6t5JJW29viByr1LDlFD_gLz1KphxM/view?usp=sharing',
      'https://drive.google.com/file/d/1N5F-qVa1-vx1pMeUPqhkKEIBWo3t4Lo7/view?usp=sharing',
      'https://drive.google.com/file/d/1SUoajS_jYBtLxCiLDMsxdl4DOg2OXGlK/view?usp=sharing',
      'https://drive.google.com/file/d/1TGHjXHyOj5TZmrbj0eI6GveUjHp2FQn6/view?usp=sharing',
      'https://drive.google.com/file/d/1V7UoqkwwE8SnCYY158DVVc30Kr3zQZEE/view?usp=sharing',
      'https://drive.google.com/file/d/1WDyW66xdR1jcNvFNdkqkONLO30TwPYzB/view?usp=sharing',
      'https://drive.google.com/file/d/1WfoW5OCKhgQMTVvNtihcjv-rqTts6n57/view?usp=sharing',
      'https://drive.google.com/file/d/1XaobbvvMapWDOY81EgLWBbV4Q_qvRBZA/view?usp=sharing',
      'https://drive.google.com/file/d/1YV2hUsY0J4Q1dfFPF88vQN4PCYkns5Fr/view?usp=sharing',
      'https://drive.google.com/file/d/1ZmoTyEhPyCI6CsO-_qx-oWnYbrvDF6lo/view?usp=sharing',
      'https://drive.google.com/file/d/1nLH6CMIF2CgyTgx-umdMYNqmcyyprdUd/view?usp=sharing',
      'https://drive.google.com/file/d/1u3sVleoORxsbyU7oJ9B3by4c5--Z-j-w/view?usp=sharing',
      'https://drive.google.com/file/d/1uity_7D0_YIJxZtgeo49WRUu81GzlHwv/view?usp=sharing',
      'https://drive.google.com/file/d/1uqxtZ27VjPVsLfk466yUP5YNtZNzP1GA/view?usp=sharing'
    ],
    'Real Estate': [
      'https://drive.google.com/file/d/16QWZg9nPaZ4I6S3DLSEYXIdXJkfs-x41/view?usp=sharing',
      'https://drive.google.com/file/d/1_jBSqGjs73JmA0jiVpKJhauXK-c9v0ym/view?usp=sharing',
      'https://drive.google.com/file/d/1xB6V0wuh3tL0UISRRjwDVcMcT2XBpbOm/view?usp=sharing'
    ],
    'Long Form': [
      'https://drive.google.com/file/d/1AEGwNYl9X9lhYww7LaYcey3Y4CO-HgJA/view?usp=sharing',
      'https://drive.google.com/file/d/1V00GHFhXjlQ7h95FewaB6UiphEGrumKV/view?usp=sharing',
      'https://drive.google.com/file/d/1f-Wf5Gk9cy3qQ9DEKYnWMM64rXaE8QZ7/view?usp=sharing',
      'https://drive.google.com/file/d/1fN2xt5FUs8_wcHjLGIZ9oLyjAgL5dFrL/view?usp=sharing',
      'https://drive.google.com/file/d/1yLgT1MrSKhT1EGU4C_poJvFrybd1bawa/view?usp=sharing'
    ],
    'Graphics': [
      'https://drive.google.com/file/d/15ZnoCulA7RfEM5kHR0V0qgJfWfeC5Pt-/view?usp=sharing',
      'https://drive.google.com/file/d/1R_CwNh6wF4liHwo2dUqFZxNZWTVTDDji/view?usp=sharing',
      'https://drive.google.com/file/d/1rDMGzzJoq9uC3Gjun2p9DkMGCEm0v1ob/view?usp=sharing',
      'https://drive.google.com/file/d/1vuUhyghpMuyfIk8DCr0ppkaZ0c5ouqR9/view?usp=sharing'
    ],
    'Self Introduction': [
      'https://drive.google.com/file/d/1mpIt4X8OwKYLM7AvIgA_edKPrrXNEgpI/view?usp=drive_link'
    ]
  };

  // Map raw links to project objects and extract thumbnail URLs
  const projects = Object.entries(rawLinks).flatMap(([category, urls]) =>
    urls.map((url, index) => {
      let titleBase = category;
      if (category === 'Self Introduction') titleBase = 'Self Introduction Video';
      else if (category.includes('Video')) titleBase = category.replace(' Videos', '');
      
      const title = category === 'Self Introduction' 
        ? titleBase 
        : `${titleBase} Project ${index + 1}`;

      // Extract Google Drive File ID for the thumbnail
      const matchId = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
      const videoId = matchId ? matchId[1] : null;
      const thumbnailUrl = videoId ? `https://drive.google.com/thumbnail?id=${videoId}&sz=w400` : null;

      return {
        id: `${category.toLowerCase().replace(/\s+/g, '-')}-${index}`,
        title: title,
        category: category,
        description: `View this ${category.toLowerCase()} directly on Google Drive. Click to open in a new tab.`,
        url: url,
        videoId: videoId,
        thumbnailUrl: thumbnailUrl
      };
    })
  );

  const filteredProjects = activeCategory === 'All'
    ? projects
    : projects.filter(project => project.category === activeCategory);

  return (
    <>
      <Helmet>
        <title>Portfolio - Johnny Paragoso</title>
        <meta name="description" content="Explore my portfolio of video editing work including AI Videos, UGC, Short Form, Real Estate, Long Form, and Graphic projects." />
      </Helmet>

      <div className="min-h-screen bg-background flex flex-col">
        <Header />

        <main className="flex-1 pb-20">
          {/* Hero Section */}
          <section className="relative w-full h-[50vh] min-h-[400px] flex items-center justify-center pt-16 mb-12 border-b border-border/50">
            {/* Background Image Container */}
            <div className="absolute inset-0 overflow-hidden">
              <img 
                src="https://drive.google.com/thumbnail?id=1eU4yWcBBafMAVMu5FZLYWK9jiYUEKjjK&sz=w1920" 
                alt="Johnny Paragoso Video Editing Portfolio" 
                className="w-full h-full object-cover"
                loading="eager"
              />
              {/* Gradient overlay to blend image seamlessly into the page background */}
              <div className="absolute inset-0 bg-gradient-to-b from-background/70 via-background/80 to-background" />
            </div>

            <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.6 }}
              >
                <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-foreground mb-6" style={{ letterSpacing: '-0.02em' }}>
                  My Work
                </h1>
                <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto text-balance">
                  A comprehensive collection of my projects across various formats, showcasing technical skills, engaging storytelling, and creative direction.
                </p>
              </motion.div>
            </div>
          </section>

          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <ProjectFilter
              categories={categories}
              activeCategory={activeCategory}
              onCategoryChange={setActiveCategory}
            />

            <AnimatePresence mode="wait">
              {filteredProjects.length > 0 ? (
                <motion.div 
                  key={activeCategory}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                  className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 auto-rows-fr"
                >
                  {filteredProjects.map((project, index) => (
                    <VideoCard key={project.id} project={project} index={index} />
                  ))}
                </motion.div>
              ) : (
                <motion.div
                  key="empty-state"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.3 }}
                  className="text-center py-24 bg-muted/30 rounded-2xl border border-border border-dashed"
                >
                  <div className="w-16 h-16 mx-auto mb-4 rounded-2xl bg-muted flex items-center justify-center">
                    <Film className="h-8 w-8 text-muted-foreground" />
                  </div>
                  <h3 className="text-xl font-semibold text-foreground mb-2">
                    No projects found
                  </h3>
                  <p className="text-muted-foreground">
                    Try selecting a different category to view more work.
                  </p>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </main>

        <Footer />
      </div>
    </>
  );
};

export default PortfolioPage;
