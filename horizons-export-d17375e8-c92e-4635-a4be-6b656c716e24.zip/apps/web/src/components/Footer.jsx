import React from 'react';
import { Link } from 'react-router-dom';
import { Instagram, Linkedin, Facebook, Mail, Phone, MapPin } from 'lucide-react';

const TikTokIcon = ({ className }) => (
  <svg className={className} viewBox="0 0 24 24" fill="currentColor">
    <path d="M19.59 6.69a4.83 4.83 0 01-3.77-4.25V2h-3.45v13.67a2.89 2.89 0 01-5.2 1.74 2.89 2.89 0 012.31-4.64 2.93 2.93 0 01.88.13V9.4a6.84 6.84 0 00-1-.05A6.33 6.33 0 005 15.68a6.34 6.34 0 006.35 6.32 6.32 6.32 0 006.31-6.24v-6.9a8.09 8.09 0 005 1.76v-3.4a4.67 4.67 0 01-3.07-.53z" />
  </svg>
);

const Footer = () => {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="bg-secondary text-secondary-foreground border-t border-border">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8">
          <div className="md:col-span-2">
            <span className="text-xl font-bold font-display">Johnny Paragoso</span>
            <p className="mt-2 text-sm opacity-80 max-w-sm leading-relaxed">
              Professional video editor crafting compelling visual stories. Transforming raw footage into cinematic masterpieces with precision and creative flair.
            </p>
            <div className="flex gap-4 mt-6">
              <a 
                href="https://www.instagram.com/johnnyparagoso/" 
                target="_blank" 
                rel="noopener noreferrer"
                className="opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
                aria-label="Instagram"
              >
                <Instagram className="h-5 w-5" />
              </a>
              <a 
                href="https://www.linkedin.com/in/johnny-paragoso-9b5a161b" 
                target="_blank" 
                rel="noopener noreferrer"
                className="opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
                aria-label="LinkedIn"
              >
                <Linkedin className="h-5 w-5" />
              </a>
              <a 
                href="https://facebook.com/johny.paragoso" 
                target="_blank" 
                rel="noopener noreferrer"
                className="opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
                aria-label="Facebook"
              >
                <Facebook className="h-5 w-5" />
              </a>
              <a 
                href="https://www.tiktok.com/@john_aiexperts" 
                target="_blank" 
                rel="noopener noreferrer"
                className="opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
                aria-label="TikTok"
              >
                <TikTokIcon className="h-5 w-5" />
              </a>
            </div>
          </div>

          <div>
            <span className="text-sm font-semibold mb-3 block">Quick Links</span>
            <div className="flex flex-col gap-2">
              <Link to="/" className="text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200">
                Home
              </Link>
              <Link to="/portfolio" className="text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200">
                Portfolio
              </Link>
              <Link to="/about" className="text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200">
                About
              </Link>
              <Link to="/contact" className="text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200">
                Contact
              </Link>
            </div>
          </div>

          <div>
            <span className="text-sm font-semibold mb-3 block">Contact Info</span>
            <div className="flex flex-col gap-3">
              <a 
                href="mailto:paragosojohnny@gmail.com"
                className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
              >
                <Mail className="h-4 w-4" />
                paragosojohnny@gmail.com
              </a>
              <a 
                href="tel:+639366674832"
                className="flex items-center gap-2 text-sm opacity-80 hover:opacity-100 hover:text-primary transition-all duration-200"
              >
                <Phone className="h-4 w-4" />
                +63 936 6674 832
              </a>
              <div className="flex items-center gap-2 text-sm opacity-80">
                <MapPin className="h-4 w-4" />
                Sulit, Ilocos, Philippines
              </div>
            </div>
          </div>
        </div>

        <div className="pt-8 border-t border-border/50 flex flex-col sm:flex-row justify-between items-center gap-4">
          <p className="text-sm opacity-70">
            © {currentYear} Johnny Paragoso. All rights reserved.
          </p>
          <div className="flex gap-6">
            <Link to="/privacy" className="text-sm opacity-70 hover:opacity-100 hover:text-primary transition-all duration-200">
              Privacy Policy
            </Link>
            <Link to="/terms" className="text-sm opacity-70 hover:opacity-100 hover:text-primary transition-all duration-200">
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;