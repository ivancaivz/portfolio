import React from 'react';
import { motion } from 'framer-motion';

const ProjectFilter = ({ categories, activeCategory, onCategoryChange }) => {
  return (
    <div className="flex flex-wrap gap-2 justify-center mb-12 p-2 bg-muted/40 rounded-2xl border border-border/50 max-w-4xl mx-auto">
      {categories.map((category) => {
        const isActive = activeCategory === category;
        return (
          <button
            key={category}
            onClick={() => onCategoryChange(category)}
            className={`relative px-4 py-2 text-sm font-medium rounded-xl transition-colors duration-200 outline-none focus-visible:ring-2 focus-visible:ring-ring ${
              isActive 
                ? 'text-primary-foreground' 
                : 'text-muted-foreground hover:text-foreground hover:bg-muted/80'
            }`}
          >
            {isActive && (
              <motion.div
                layoutId="activeCategoryFilter"
                className="absolute inset-0 bg-primary rounded-xl"
                transition={{ type: "spring", stiffness: 400, damping: 30 }}
                style={{ zIndex: 0 }}
              />
            )}
            <span className="relative z-10">{category}</span>
          </button>
        );
      })}
    </div>
  );
};

export default ProjectFilter;