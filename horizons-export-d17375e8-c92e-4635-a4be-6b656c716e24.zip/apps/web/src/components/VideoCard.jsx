
import React from 'react';
import { motion } from 'framer-motion';
import { Play, Image as ImageIcon, ExternalLink } from 'lucide-react';

const VideoCard = ({ project, index }) => {
  const isLarge = index === 0;
  const isGraphics = project.category === 'Graphics';
  const Icon = isGraphics ? ImageIcon : Play;

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5, delay: index * 0.05 }}
      className={`group relative rounded-2xl overflow-hidden bg-card border border-border/50 shadow-sm hover:shadow-xl hover:-translate-y-1 transition-all duration-300 flex flex-col h-full ${
        isLarge ? 'md:col-span-2 md:row-span-2' : ''
      }`}
    >
      <a 
        href={project.url} 
        target="_blank" 
        rel="noopener noreferrer"
        className="block h-full flex flex-col"
      >
        <div className={`relative ${isLarge ? 'aspect-video md:aspect-auto md:h-[400px]' : 'aspect-video'} bg-muted overflow-hidden`}>
          {/* Thumbnail Image */}
          {project.thumbnailUrl ? (
            <img 
              src={project.thumbnailUrl} 
              alt={project.title}
              className="absolute inset-0 w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
              loading="lazy"
            />
          ) : (
            <div className="absolute inset-0 bg-gradient-to-br from-muted-foreground/10 to-background" />
          )}
          
          {/* Dark overlay for better icon visibility and contrast */}
          <div className="absolute inset-0 bg-black/20 group-hover:bg-black/40 transition-colors duration-300" />
          
          {/* Centered Play/Image Icon */}
          <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
            <div className="w-14 h-14 rounded-full bg-primary/90 backdrop-blur-md flex items-center justify-center group-hover:bg-primary group-hover:scale-110 transition-all duration-300 shadow-lg">
              <Icon className={`h-6 w-6 text-primary-foreground ${!isGraphics && 'ml-1'}`} />
            </div>
          </div>

          {/* Hover Open Overlay */}
          <div className="absolute inset-0 bg-card/80 backdrop-blur-sm opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
            <span className="flex items-center gap-2 text-foreground font-medium px-5 py-2.5 rounded-full bg-background/80 border border-border shadow-sm">
              <ExternalLink className="w-4 h-4" />
              Open in Drive
            </span>
          </div>
        </div>

        <div className="p-6 flex-1 flex flex-col">
          <div className="flex items-center gap-2 mb-3">
            <span className="text-xs font-semibold px-2.5 py-1 rounded-md bg-primary/10 text-primary tracking-wide uppercase">
              {project.category}
            </span>
          </div>
          <h3 className="text-xl font-semibold mb-2 text-card-foreground group-hover:text-primary transition-colors duration-200 line-clamp-2">
            {project.title}
          </h3>
          <p className="text-sm text-muted-foreground leading-relaxed mt-auto">
            {project.description}
          </p>
        </div>
      </a>
    </motion.div>
  );
};

export default VideoCard;
